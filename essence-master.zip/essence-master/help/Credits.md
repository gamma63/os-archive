# Credits

Thank you to all the people who have contributed to Essence!

## Contributors

Put your name here!

- nakst
- Brett R. Toomey
- vtlmks
- Aleksander Birkeland

## Included projects

Licenses for included projects may be found in the following files:

- `util/nanosvg.h`
- `util/hsluv.h`
- `shared/stb_image.h`, `shared/stb_sprintf.h`, `shared/stb_ds.h` and `util/stb_truetype.h`
- `res/Fonts/Hack License.txt`, `res/Fonts/Inter License.txt`
- `res/Icons/elementary Icons License.txt`
- `res/Sample Images/Licenses.txt`
- `res/Keyboard Layouts/License.txt`
- Ported applications have their licenses in their respective folders in `ports/`.
