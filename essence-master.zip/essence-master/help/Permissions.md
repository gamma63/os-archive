# Permissions

This file has not been written yet. `Notes from Discord.txt` may contain a few unorganized pointers, though.

## Overview

TODO

## Application permissions

TODO

- `permission_all_files`
- `permission_all_devices`
- `permission_manage_processes`
- `permission_posix_subsystem`
- `permission_run_temporary_application`
- `permission_shutdown`
- `permission_view_file_types`
- `permission_start_application`

## Kernel permissions

TODO

- `ES_PERMISSION_NETWORKING`
- `ES_PERMISSION_PROCESS_CREATE`
- `ES_PERMISSION_PROCESS_OPEN`
- `ES_PERMISSION_SCREEN_MODIFY`
- `ES_PERMISSION_SHUTDOWN`
- `ES_PERMISSION_TAKE_SYSTEM_SNAPSHOT`
- `ES_PERMISSION_GET_VOLUME_INFORMATION`
- `ES_PERMISSION_WINDOW_MANAGER`
