The protocol directory contains non Architectural 
Protocols that span the FW, Platform, or application
space.