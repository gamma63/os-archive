#include <stdio.h>
#include <essence.h>

int main(int argc, char **argv) {
	printf("Hello, world!\n");
	return 0;
}
