This project is released under the MIT License. Please note that some files bundled in the source tree are taken from other projects which are made available under different licenses; these cases are detailed at the end of this file.

Copyright (c) 2017-2022 nakst and other contributors (see CONTRIBUTING.md).

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

This project also include the work of other projects.
Their licenses may be found in the following files:
* `util/nanosvg.h`
* `util/hsluv.h`
* `shared/stb_image.h`, `shared/stb_sprintf.h`, `shared/stb_ds.h` and `util/stb_truetype.h`
* `res/Fonts/Hack License.txt`, `res/Fonts/Inter License.txt`, `res/Fonts/Atkinson Hyperlegible License.txt`, `res/Fonts/OpenDyslexic License.txt`
* `res/Icons/elementary Icons License.txt`
* `res/Sample Images/Licenses.txt`
* `res/Keyboard Layouts/License.txt`
* Ported applications have their licenses in their respective folders in `ports/`.
All trademarks are registered trademarks of their respective owners.
Please tell me if I've forgotten something!
