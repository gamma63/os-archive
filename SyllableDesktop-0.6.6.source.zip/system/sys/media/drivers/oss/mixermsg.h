
#ifndef _MESSAGES_H_
#define _MESSAGES_H_


#define MESSAGE_CHANNEL_CHANGED 0
#define MESSAGE_LOCK_CHANGED 1


#endif
